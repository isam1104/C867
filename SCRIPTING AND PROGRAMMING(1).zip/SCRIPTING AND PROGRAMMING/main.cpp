#include "roster.h"
#include <iostream>

int main() {
    Roster roster(5);
    std::string studentData[] = {"A1,John,Smith,John1989@gmail.com,20,30,35,40,SECURITY",
                                 "A2,Suzan,Erickson,Erickson_1990@gmail.com,19,50,30,40,NETWORK",
                                 "A3,Jack,Napoli,The_lawyer99@yahoo.com,19,20,40,33,SOFTWARE",
                                 "A4,Erin,Black,Erin.black@comcast.net,22,50,58,40,SECURITY",
                                 "A5,David,Thomas,david_thomas@gmail.com,25,40,35,50,SOFTWARE"};

    for (int i = 0; i < 5; i++) {
        std::string data = studentData[i];
        int lastComma = data.find_last_of(',');
        DegreeProgram degree = (DegreeProgram)stoi(data.substr(lastComma + 1));
        data = data.substr(0, lastComma);
        lastComma = data.find_last_of(',');
        int daysInCourse3 = stoi(data.substr(lastComma + 1));
        data = data.substr(0, lastComma);
        lastComma = data.find_last_of(',');
        int daysInCourse2 = stoi(data.substr(lastComma + 1));
        data = data.substr(0, lastComma);
        lastComma = data.find_last_of(',');
        int daysInCourse1 = stoi(data.substr(lastComma + 1));
        data = data.substr(0, lastComma);
        lastComma = data.find_last_of(',');
        int age = stoi(data.substr(lastComma + 1));
        data = data.substr(0, lastComma);
        lastComma = data.find_last_of(',');
        std::string email = data.substr(lastComma + 1);
        data = data.substr(0, lastComma);
        lastComma = data.find_last_of(',');
        std::string lastName = data.substr(lastComma + 1);
        data = data.substr(0, lastComma);
        lastComma = data.find_last_of(',');
        std::string firstName = data.substr(lastComma + 1);
        std::string studentId = data.substr(0, lastComma);

        roster.add(studentId, firstName, lastName, email, age, daysInCourse1, daysInCourse2, daysInCourse3, degree);
    }

    std::cout << "All students:" << std::endl;
    roster.printAll();
    std::cout << std::endl;

    std::c

int main() {
    std::cout << "Course Title: C867 - Scripting and Programming Applications" << std::endl;
    std::cout << "Programming Language Used: C++" << std::endl;
    std::cout << "WGU Student ID: 001112222" << std::endl;
    std::cout << "Student Name: John Doe" << std::endl;

    Roster classRoster;

    // code to add, remove, and print students from classRoster

    return 0;
}
  Roster classRoster;
  classRoster.printAll();
  classRoster.printInvalidEmails();