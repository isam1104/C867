#ifndef STUDENT_H
#define STUDENT_H

#include <string>
#include "degree.h"

class Student {
    private:
        std::string studentId;
        std::string firstName;
        std::string lastName;
        std::string email;
        int age;
        int daysInCourse[3];
        DegreeProgram degree;

    public:
        Student();
        Student(std::string studentId, std::string firstName, std::string lastName, std::string email, int age, int daysInCourse[], DegreeProgram degree);
        Student(std::string studentId, std::string firstName, std::string lastName, std::string email, int age, int daysInCourse[3], DegreeProgram degree);
        std::string getStudentId(); // Accessor
        std::string getFirstName();
        std::string getLastName();
        std::string getEmail();
        int getAge();
        int* getDaysInCourse();
        DegreeProgram getDegree();
        void setStudentId(std::string studentId); //Mutator
        void setFirstName(std::string firstName);
        void setLastName(std::string lastName);
        void setEmail(std::string email);
        void setAge(int age);
        void setDaysInCourse(int daysInCourse[]);
        void setDegree(DegreeProgram degree);
        void print(); // Print specific student data
};

#endif
#include "student.h"

Student::Student(std::string studentId, std::string firstName, std::string lastName, std::string email, int age, int daysInCourse[3], DegreeProgram degree) {
    this->studentId = studentId;
    this->firstName = firstName;
    this->lastName = lastName;
    this->email = email;
    this->age = age;
    for (int i = 0; i < 3; i++) {
        this->daysInCourse[i] = daysInCourse[i];
    }
    this->degree = degree;
}

std::string Student::getStudentId() {
    return studentId;
}

std::string Student::getFirstName() {
    return firstName;
}

std::string Student::getLastName() {
    return lastName;
}

std::string Student::getEmail() {
    return email;
}

int Student::getAge() {
    return age;
}

int* Student::getDaysInCourse() {
    return daysInCourse;
}

DegreeProgram Student::getDegree() {
    return degree;
}

void Student::setStudentId(std::string studentId) {
    this->studentId = studentId;
}

void Student::setFirstName(std::string firstName) {
    this->firstName = firstName;
}

void Student::setLastName(std::string lastName) {
    this->lastName = lastName;
}

void Student::setEmail(std::string email) {
    this->email = email;
}

void Student::setAge(int age) {
    this->age = age;
}

void Student::setDaysInCourse(int daysInCourse[]) {
    for (int i = 0; i < 3; i++) {
        this->daysInCourse[i] = daysInCourse[i];
    }
}

void Student::setDegree(DegreeProgram degree) {
    this->degree = degree;
}

void Student::print() {
    std::cout << "Student ID: " << studentId << std::endl;
    std::cout << "First Name: " << firstName << std::endl;
    std::cout << "Last Name: " << lastName << std::endl;
    std::cout << "Email: " << email << std::endl;
    std::cout << "Age: " << age << std::endl;
    std::cout << "Days In Course: {";
    for (int i = 0; i < 3; i++) {
        std::cout << daysInCourse[i];
        if (i < 2) {
            std::cout << ", ";
        }
    }
    std::cout << "}" << std::endl;
    std::cout << "Degree: ";
    if (degree == SECURITY) {
        std::cout << "SECURITY" << std::endl;
    }
    else if (degree == NETWORK) {
        std::cout << "NETWORK" << std::endl;
    }
    else
