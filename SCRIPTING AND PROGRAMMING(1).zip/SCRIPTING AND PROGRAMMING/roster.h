#ifndef ROSTER_H
#define ROSTER_H

#include "student.h"

class Roster {
    private:
        int lastIndex;
        int capacity;
        Student** classRosterArray;

    public:
        Roster();
        Roster(int capacity);
        void add(std::string studentId, std::string firstName, std::string lastName, std::string email, int age, int daysInCourse1, int daysInCourse2, int daysInCourse3, DegreeProgram degree);
        void remove(std::string studentId);
        void printAll();
        void printAverageDaysInCourse(std::string studentId);
        void printInvalidEmails();
        void printByDegreeProgram(DegreeProgram degree);
};

#endif

const int numStudents = 5;

Roster::Roster() {
    this->classRosterArray = new Student*[numStudents];
}

void Roster::add(std::string studentId, std::string firstName, std::string lastName, std::string email, int age, int daysInCourse1, int daysInCourse2, int daysInCourse3, DegreeProgram degree) {
    int daysInCourse[] = { daysInCourse1, daysInCourse2, daysInCourse3 };
    Student* newStudent = new Student(studentId, firstName, lastName, email, age, daysInCourse, degree);
    for (int i = 0; i < numStudents; i++) {
        if (classRosterArray[i] == nullptr) {
            classRosterArray[i] = newStudent;
            break;
        }
    }
}