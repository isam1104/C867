#include "student.h"

Student::Student() {
    // Default constructor
}

Student::Student(std::string studentId, std::string firstName, std::string lastName, std::string email, int age, int daysInCourse[], DegreeProgram degree) {
    this->studentId = studentId;
    this->firstName = firstName;
    this->lastName = lastName;
    this->email = email;
    this->age = age;
    this->daysInCourse[0] = daysInCourse[0];
    this->daysInCourse[1] = daysInCourse[1];
    this->daysInCourse[2] = daysInCourse[2];
    this->degree = degree;
}

std::string Student::getStudentId() {
    return studentId;
}

std::string Student::getFirstName() {
    return firstName;
}

std::string Student::getLastName() {
    return lastName;
}

std::string Student::getEmail() {
    return email;
}

int Student::getAge() {
    return age;
}

int* Student::getDaysInCourse() {
    return daysInCourse;
}

DegreeProgram Student::getDegree() {
    return degree;
}

void Student::setStudent
