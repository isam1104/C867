#include "roster.h"

const int numStudents = 5;

Roster::Roster() {
    this->classRosterArray = new Student*[numStudents];
}

void Roster::printAll() {
    for (int i = 0; i < numStudents; i++) {
        if (classRosterArray[i] != nullptr) {
            classRosterArray[i]->print();
        }
    }
}

Roster::Roster() {
    // Default constructor
    lastIndex = -1;
    this->capacity = 0;
    classRosterArray = nullptr;
}
void Roster::printByDegreeProgram(DegreeProgram degreeProgram) {
    for (int i = 0; i < numStudents; i++) {
        if (classRosterArray[i] != nullptr && classRosterArray[i]->getDegreeProgram() == degreeProgram) {
            classRosterArray[i]->print();
        }
    }
}

Roster::Roster(int capacity) {
    lastIndex = -1;
    this->capacity = capacity;
    classRosterArray = new Student*[capacity];
}

void Roster::add(std::string studentId, std::string firstName, std::string lastName, std::string email, int age, int daysInCourse1, int daysInCourse2, int daysInCourse3, DegreeProgram degree) {
    int daysInCourse[] = {daysInCourse1, daysInCourse2, daysInCourse3};
    if (lastIndex < capacity) {
        classRosterArray[++lastIndex] = new Student(studentId, firstName, lastName, email, age, daysInCourse, degree);
    }
}

void Roster::remove(std::string studentId) {
    bool found = false;
    for (int i = 0; i <= lastIndex; i++) {
        if (classRosterArray[i]->getStudentId() == studentId) {
            found = true;
            delete classRosterArray[i];
            classRosterArray[i] = classRosterArray[lastIndex--];
        }
    }
    if (!found) {
        std::cout << "Error: Student ID " << studentId << " not found." << std::endl;
    }
}
/// prints a complete tab-separated list of student data
void Roster::printAll() {
    for (int i = 0; i < numStudents; i++) {
        if (classRosterArray[i] != nullptr) {
            classRosterArray[i]->print();
        }
    }
}

void Roster::printAverageDaysInCourse(std::string studentId) {
    bool found = false;
    for (int i = 0; i <= lastIndex; i++) {
        if (classRosterArray[i]->getStudentId() == studentId) {
            found = true;
            int* daysInCourse = classRosterArray[i]->getDaysInCourse();
            int average = (daysInCourse[0] + daysInCourse[1] + daysInCourse[2]) / 3;
            std::cout << "Student ID: " << studentId << " - Average days in course: " << average << std::endl;
        }
    }
    if (!found) {
        std::cout << "Error: Student ID " << studentId << " not found." << std::endl;
    }
}

void Roster::printInvalidEmails() {
    std::cout << "Invalid email addresses: " << std::endl;
    for (int i = 0; i < numStudents; i++) {
        if (classRosterArray[i] != nullptr) {
            std::string email = classRosterArray[i]->getEmail();
            bool validEmail = true;

            // check if email contains '@' and '.'
            if (email.find('@') == std::string::npos || email.find('.') == std::string::npos) {
                validEmail = false;
            }

            // check if '@' comes before '.'
            if (validEmail && email.find('@') > email.find('.')) {
                validEmail = false;
            }

            // check if email address ends with '.'
            if (validEmail && email.back() == '.') {
                validEmail = false;
            }

            if (!validEmail) {
                std::cout << email << std::endl;
            }
        }
    }
}

#include "roster.h"

const int numStudents = 5;

Roster::Roster() {
    this->classRosterArray = new Student*[numStudents];
}

void Roster::add(std::string studentData) {
    std::string studentId, firstName, lastName, email, age, daysInCourse1, daysInCourse2, daysInCourse3, degree;
    int ageInt, daysInCourse1Int, daysInCourse2Int, daysInCourse3Int;

    // Parse studentData and extract information
    std::stringstream ss(studentData);
    getline(ss, studentId, ',');
    getline(ss, firstName, ',');
    getline(ss, lastName, ',');
    getline(ss, email, ',');
    getline(ss, age, ',');
    getline(ss, daysInCourse1, ',');
    getline(ss, daysInCourse2, ',');
    getline(ss, daysInCourse3, ',');
    getline(ss, degree, ',');

    // Convert age and daysInCourse to int
    ageInt = stoi(age);
    daysInCourse1Int = stoi(daysInCourse1);
    daysInCourse2Int = stoi(daysInCourse2);
    daysInCourse3Int = stoi(daysInCourse3);

    // Determine degreeProgram
    DegreeProgram degreeProgram;
    if (degree == "SECURITY") {
        degreeProgram = SECURITY;
    }
    else if (degree == "NETWORK") {
        degreeProgram = NETWORK;
    }
    else if (degree == "SOFTWARE") {
        degreeProgram = SOFTWARE;
    }

    // Create new student object and add to classRosterArray
    int daysInCourse[] = { daysInCourse1Int, daysInCourse2Int, daysInCourse3Int };
    Student* newStudent = new Student(studentId, firstName, lastName, email, ageInt, daysInCourse, degreeProgram);
    for (int i = 0; i < numStudents; i++) {
        if (classRosterArray[i] == nullptr) {
            classRosterArray[i] = newStudent;
            break;
        }
    }
}
